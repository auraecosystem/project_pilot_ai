<div class="main-content">
	<div class="wrapper-surly">
		<div class="ps-window">
			<div class="ps-central-content">
				<div class="ps-rows-settings">
					<div class="ps-row-box">
						<div class="ps-inner-box">
							<div class="ps-title-box">
								<p><?php echo $lang_surly['configure your toolbar']; ?></p>
							</div>
							<div class="ps-settings-out">
								<iframe frameborder="0" scrolling="no" class="surly-settings-toolbar" name="settings" src="<?php echo SURLY_PANEL_URL . surly_get_option('surly_toolbar_id', '') . '/plugin_access?password=' . surly_get_option('surly_toolbar_password', ''); ?>"></iframe>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>