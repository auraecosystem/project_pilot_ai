<?php
/**
*
* @package Sur.ly
* @copyright (c) 2014 Sur.ly <http://sur.ly>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace surly\surly\migrations\v10x;

/**
* Migration stage 2: Initial data
*/
class m2_initial_data extends \phpbb\db\migration\migration
{
	/**
	* Add or update data in the database
	*
	* @return array Array of table data
	* @access public
	*/
	public function update_data()
	{
		return array(
			array('config.add', array('surly_check_secondary_groups', false)),
			array('config.add', array('surly_shorten_urls', false)),
			array('config.add', array('surly_url_processing', false)),
			array('config.add', array('surly_trusted_groups', '')),
			array('config.add', array('surly_ignore_domains', '')),
			array('config.add', array('surly_subdomain', '')),
		);
	}
}
