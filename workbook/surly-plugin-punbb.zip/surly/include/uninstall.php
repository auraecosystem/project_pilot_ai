<?php

if (!defined('SURLY_UNINSTALL')) die();

require_once $ext_info['path'] . '/include/functions.php';

$forum_db->drop_table('shortener_cache');

$surly_config = array(
	'surly_trusted_domains',
	'surly_trusted_groups',
	'surly_shorten_urls',
	'surly_toolbar_id',
	'surly_toolbar_password',
	'surly_subdomain',
	'surly_replace_urls',
	'surly_initial',
	'surly_activation_hash',
);

foreach ($surly_config as $conf_name) {

	$conf_name = 'o_' . $conf_name;

	$forum_db->query_build(array(
		'DELETE' => 'config',
		'WHERE' => 'conf_name="' . $forum_db->escape($conf_name) . '"'
	)) or error(__FILE__, __LINE__);
}

$surly = surly_get_sdk();
$surly->trackHistory(SURLY_ACTION_TYPE_UNINSTALL);