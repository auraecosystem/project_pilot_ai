<div class="main-content">
	<div class="wrapper-surly" data-token="<?php echo generate_form_token(forum_link($forum_url['surly'])); ?>">
		<div class="ps-window">
			<div class="ps-top-title">
				<p><?php echo $lang_surly['sur.ly plugin settings']; ?></p>
			</div>
			<div class="ps-window-content">
				<div class="ps-left-side">
					<div class="ps-left-content">
						<div class="ps-step-menu">
							<ul id="initial-steps" class="ps-menu">
								<li>
									<div class="ps-num-item"><span>1</span></div>
									<div class="ps-name-item"><p><span><?php echo $lang_surly['registration']; ?></span></p></div>
								</li>
								<li>
									<div class="ps-num-item"><span>2</span></div>
									<div class="ps-name-item"><p><span><?php echo $lang_surly['domains']; ?></span></p></div>
									<div class="ps-sub-menu">
										<ul>
											<li>
												<span class="sline"></span>
												<div class="ps-sub-name-item"><p><span><?php echo $lang_surly['use your subdomain']; ?></span></p></div>
											</li>
											<li>
												<span class="sline hlast"></span>
												<div class="ps-sub-name-item"><p><span><?php echo $lang_surly['trusted domains']; ?></span></p></div>
											</li>
										</ul>
									</div>
								</li>
								<li>
									<div class="ps-num-item"><span>3</span></div>
									<div class="ps-name-item"><p><span><?php echo $lang_surly['trusted groups']; ?></span></p></div>
								</li>
								<li>
									<div class="ps-num-item"><span>4</span></div>
									<div class="ps-name-item"><p><span><?php echo $lang_surly['url processing']; ?></span></p></div>
									<div class="ps-sub-menu">
										<ul>
											<li>
												<span class="sline"></span>
												<div class="ps-sub-name-item"><p><span><?php echo $lang_surly['shorten urls']; ?></span></p></div>
											</li>
											<li>
												<div class="ps-sub-name-item"><p><span><?php echo $lang_surly['replace urls']; ?></span></p></div>
											</li>
										</ul>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="ps-right-side">
					<div class="ps-right-content">
						<div id="surly-initial-step-1-0" style="display:none">
							<?php if (!surly_get_option('surly_toolbar_id')): ?>
								<iframe frameborder="0" scrolling="no" class="surly-auth" src="" data-src="https://surdotly.com/settings/auth/?<?php echo http_build_query(array('url' => $base_url, 'cmsId' => 4, 'meta' => array('cms_version' => FORUM_VERSION))); ?>"></iframe>
							<?php endif; ?>
						</div>
						<form id="surly-initial-step-2-1" style="display:none">
							<input type="hidden" name="csrf_token" value="<?php echo generate_form_token(forum_link($forum_url['surly'])); ?>"/>
							<input type="hidden" name="action" value="surly_ajax_save_subdomain"/>
							<div class="ps-info-text">
								<p><?php echo sprintf($lang_surly['set up a subdomain'], 'https://surdotly.com/setting_subdomain#dns'); ?></p>
							</div>
							<div class="ps-cell">
								<div class="surly-field-error" data-field="surly-subdomain"></div>
							</div>
							<div class="ps-next-form">
								<div class="ps-left-row">
									<div class="ps-list">
										<ul>
											<li>
												<div class="ps-type-in">
													<input name="surly_subdomain" value="<?php echo surly_get_option('surly_subdomain', ''); ?>" type="text" placeholder="<?php echo $lang_surly['url']; ?>"/>
												</div>
											</li>
											<li>
												<div class="ps-type-buttons">
													<a id="surly-save-subdomain" href="#" class="ps-type-button ps-icon blue"><?php echo $lang_surly['next']; ?><span> &rarr;</span></a>
												</div>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</form>
						<div id="surly-initial-step-2-2" style="display:none">
							<div class="ps-info-text">
								<p><?php echo $lang_surly['list your project’s link building partners']; ?></p>
							</div>
							<div class="ps-next-form">
								<div class="ps-list">
									<ul>
										<li>
											<form id="surly-trusted-domains">
												<div class="ps-adding">
													<div class="ps-inner-box">
														<div class="ps-table-box">
															<div class="ps-cell">
																<div class="w430">
																	<div class="ps-type-in">
																		<input id="surly-trusted-domain" name="surly_trusted_domain" value="" placeholder="<?php echo $lang_surly['domain']; ?>"/>
																		<div class="ps-type-buttons">
																			<a id="surly-save-trusted-domain" href="#" class="ps-type-button blue"><?php echo $lang_surly['add domain']; ?></a>
																		</div>
																	</div>
																</div>
															</div>
															<div class="ps-cell">
																<div class="surly-field-error" data-field="surly-trusted-domain"></div>
															</div>
														</div>
														<div class="ps-central-box">
															<div class="ps-table-line">
																<ul>
																	<li class="first">
																		<span class="ps-type-check">
																			<input type="checkbox" id="surly_trusted_domains">
																		</span>
																		<label for="surly_trusted_domains"><?php echo $lang_surly['domain']; ?></label>
																		<span class="num-item">
																			<?php if (count(surly_get_option('surly_trusted_domains', array(), true)) == 1): ?>
																				1 <?php echo $lang_surly['item']; ?>
																			<?php else: ?>
																				<?php echo count(surly_get_option('surly_trusted_domains', array(), true)); ?> <?php echo $lang_surly['items']; ?>
																			<?php endif; ?>
																		</span>
																	</li>
																	<?php foreach (surly_get_option('surly_trusted_domains', array(), true) as $key => $value): ?>
																		<li class="inner">
																			<span class="ps-type-check">
																				<input
																					id="surly_trusted_domains-<?php echo $key; ?>"
																					name="surly_trusted_domains[]"
																					value="<?php echo $value; ?>"
																					type="checkbox"/>
																			</span>
																			<label for="surly_trusted_domains-<?php echo $key; ?>"><?php echo $value; ?></label>
																		</li>
																	<?php endforeach ;?>
																	<?php if (surly_get_option('surly_trusted_domains', array(), true)): ?>
																		<li class="empty" style="display:none;"><label><?php echo $lang_surly['no items found']; ?></label></li>
																	<?php else: ?>
																		<li class="empty"><label><?php echo $lang_surly['no items found']; ?></label></li>
																	<?php endif; ?>
																</ul>
																<div class="ps-type-buttons">
																	<a id="surly-delete-trusted-domains" href="#" class="ps-type-button ps-border lred pad30"><?php echo $lang_surly['delete']; ?></a>
																</div>
															</div>
														</div>
													</div>
												</div>
											</form>
										</li>
										<li>
											<div class="ps-type-buttons">
												<a id="surly-save-trusted-domains" href="#" class="ps-type-button ps-icon blue"><?php echo $lang_surly['next']; ?><span> &rarr;</span></a>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<form id="surly-initial-step-3-0" style="display:none">
							<input type="hidden" name="csrf_token" value="<?php echo generate_form_token(forum_link($forum_url['surly'])); ?>"/>
							<input type="hidden" name="action" value="surly_ajax_save_trusted_groups"/>
							<div class="ps-info-text">
								<p><?php echo $lang_surly['select the trusted user groups']; ?></p>
							</div>
							<div class="ps-next-form">
								<div class="ps-left-row">
									<div class="ps-list">
										<ul>
											<li>
												<div class="ps-list-in trusted-groups">
													<ul>
														<?php foreach(surly_get_groups() as $key => $value): ?>
															<li>
																<label for="surly_trusted_groups-<?php echo $key; ?>">
																	<?php echo $value; ?>
																</label>
																<input
																	id="surly_trusted_groups-<?php echo $key; ?>"
																	name="surly_trusted_groups[]"
																	value="<?php echo $key; ?>"
																	type="checkbox"
																	<?php if (in_array($key, surly_get_option('surly_trusted_groups', array(), true))): ?>checked="checked"<?php endif; ?>/>
															</li>
														<?php endforeach; ?>
													</ul>
												</div>
											</li>
											<li>
												<div class="ps-type-buttons">
													<a id="surly-save-trusted-groups" href="#" class="ps-type-button ps-icon blue"><?php echo $lang_surly['next']; ?><span> &rarr;</span></a>
												</div>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</form>
						<form id="surly-initial-step-4-1" style="display:none">
							<input type="hidden" name="csrf_token" value="<?php echo generate_form_token(forum_link($forum_url['surly'])); ?>"/>
							<input type="hidden" name="action" value="surly_ajax_save_shorten_urls"/>
							<div class="ps-info-text">
								<p><?php echo sprintf($lang_surly['enable url shortening'], surly_get_option('surly_toolbar_id', SURLY_DEFAULT_TOOLBAR_ID)); ?></p>
							</div>
							<div class="ps-next-form">
								<div class="ps-left-row">
									<div class="ps-list">
										<ul>
											<li>
												<div class="ps-select-in">
													<select name="surly_shorten_urls">
														<option value="0"<?php if (!surly_get_option('surly_shorten_urls', false)): ?> selected="selected"<?php endif; ?>><?php echo $lang_surly['disable']; ?></option>
														<option value="1"<?php if (surly_get_option('surly_shorten_urls', false)): ?> selected="selected"<?php endif; ?>><?php echo $lang_surly['enable']; ?></option>
													</select>
												</div>
											</li>
											<li>
												<div class="ps-type-buttons">
													<a id="surly-save-shorten-urls" href="#" class="ps-type-button ps-icon blue"><?php echo $lang_surly['next']; ?><span> &rarr;</span></a>
												</div>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</form>
						<form id="surly-initial-step-4-2" style="display:none">
							<input type="hidden" name="csrf_token" value="<?php echo generate_form_token(forum_link($forum_url['surly'])); ?>"/>
							<input type="hidden" name="action" value="surly_ajax_save_replace_urls"/>
							<div class="ps-info-text">
								<p><? echo $lang_surly['sur.ly can work for all outbound links on your site']; ?></p>
							</div>
							<div class="ps-next-form">
								<div class="ps-left-row">
									<div class="ps-list">
										<ul>
											<li>
												<div class="ps-list-in">
													<ul>
														<li>
															<label for="surly_replace_urls_nowhere"><?php echo $lang_surly['nowhere']; ?></label>
															<input
																id="surly_replace_urls_nowhere"
																name="surly_replace_urls[]"
																value="0"
																type="checkbox"
																<?php if (in_array(0, surly_get_option('surly_replace_urls', array(0), true))): ?>checked="checked"<?php endif; ?>/>
														</li>
														<li>
															<label for="surly_replace_urls_posts"><?php echo $lang_surly['posts']; ?></label>
															<input
																id="surly_replace_urls_posts"
																name="surly_replace_urls[]"
																value="1"
																type="checkbox"
																<?php if (in_array(1, surly_get_option('surly_replace_urls', array(0), true))): ?>checked="checked"<?php endif; ?>/>
														</li>
													</ul>
												</div>
											</li>
											<li>
												<div class="ps-type-buttons">
													<a id="surly-save-replace-urls" href="#" class="ps-type-button blue"><?php echo $lang_surly['finish']; ?></a>
												</div>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php if (version_compare($forum_config['o_cur_version'], '1.4', '<')) { ?>
	<script type="text/javascript">
		$jqSurly(document).ready(function() {
			surly.initialStep('<?php echo surly_get_option('surly_initial', '1-0'); ?>');
		});
	</script>
<?php } else { ?>
	<?php $forum_loader->add_js('$jqSurly(document).ready(function() { surly.initialStep("' . surly_get_option('surly_initial', '1-0') . '") })', array('type' => 'inline')); ?>
<?php } ?>

