<?php
/*
 * Copyright (c) 2012-2017 Sur.ly
 * This file is part of Sur.ly PunBB plugin.
 * 
 * Sur.ly PunBB plugin plugin is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Sur.ly PunBB plugin is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Sur.ly PunBB plugin.  If not, see <http://www.gnu.org/licenses/>.
 */

if (!defined('FORUM')) die();

$lang_surly = array(
	// tabs
	'sur.ly plugin settings' => 'Sur.ly plugin settings',
	'toolbar settings' => 'Toolbar settings',
	// errors
	'invalid subdomain name' => 'Invalid subdomain name: please check spelling and punctuation.',
	'is not subdomain, need valid subdomain' => 'Please use your website’s existing subdomain.',
	'subdomain already in use' => 'Sorry, this subdomain is already in use.',
	'invalid cname record' => 'Incorrect CNAME record, please check your subdomain settings.',
	'invalid domain name' => 'Invalid domain name: please check spelling and punctuation.',
	'domain exists' => 'This domain is already in the list.',
	'links not protected' => 'Your website and visitors are not yet protected by Sur.ly. Be sure to enable it for your outbound links.',
	'an unexpected error occured' => 'An unexpected error occured, and we are sorry about it.',
	// titles
	'configure your toolbar' => 'Configure your toolbar',
	'url processing' => 'URL processing',
	'replace urls' => 'Replace URLs',
	'shorten urls' => 'Shorten URLs',
	'domains' => 'Domains',
	'use your subdomain' => 'Use your subdomain',
	'trusted domains' => 'Trusted domains',
	'trusted groups' => 'Trusted groups',
	'registration' => 'Registration',
	'customize surly' => 'Customize Sur.ly for maximum effect',
	// descriptions
	'set up a subdomain' => 'If you have a subdomain set up according to <a href="%s">instructions</a>, just enter its name to allow viewing external pages via it.',
	'list your project’s link building partners' => 'List your project’s link building partners (or other trusted websites) here and keep all the outbound linking to their domains & subdomains untouched.',
	'select the trusted user groups' => 'Select the trusted user groups whose links should stay untouched.',
	'enable url shortening' => 'Enable URL shortening (optionally): all links replaced by Sur.ly will be shortened and formatted like http://sur.ly/o/bN/%s.',
	'sur.ly can work for all outbound links on your site' => 'Sur.ly can work for links in Comments, Posts, or for all outbound links on your site.',
	// other
	'settings saved' => 'Settings saved.',
	'next' => 'Next',
	'finish' => 'Finish',
	'url' => 'URL',
	'domain' => 'Domain',
	'add domain' => 'Add domain',
	'item' => 'item',
	'items' => 'items',
	'no items found' => 'No items found',
	'delete' => 'Delete',
	'enable' => 'Enable',
	'disable' => 'Disable',
	'nowhere' => 'Nowhere',
	'posts' => 'Posts',
	'save changes' => 'Save changes',
	'configure surly' => 'Configure Sur.ly',
	'get the most out' => 'and get the most out of outbound links with fine tuning.',
);
