<div class="main-content">
	<div class="wrapper-surly" data-token="<?php echo generate_form_token(forum_link($forum_url['surly'])); ?>">
		<div id="surly-message" class="updated notice notice-success is-dismissible" style="display:none"><p><?php echo $lang_surly['settings saved']; ?></p></div>
		<div class="ps-window">
			<div class="ps-central-content">
				<div class="ps-top-title">
					<p>Sur.ly</p>
				</div>
				<div class="ps-rows-settings">
					<form id="surly-save-settings-form">
						<input type="hidden" name="csrf_token" value="<?php echo generate_form_token(forum_link($forum_url['surly'])); ?>"/>
						<input type="hidden" name="action" value="surly_ajax_save_settings"/>
						<div id="surly-replace-urls" class="ps-row-box">
							<div class="ps-inner-box">
								<div class="ps-title-box">
									<p><?php echo $lang_surly['replace urls']; ?></p>
								</div>
								<div class="ps-table-box">
									<div class="ps-cell">
										<div class="w280">
											<div class="ps-list-in<?php if (in_array(0, surly_get_option('surly_replace_urls', array(0), true))): ?> field-error<?php endif; ?>">
												<ul>
													<li>
														<label for="surly_replace_urls_nowhere"><?php echo $lang_surly['nowhere']; ?></label>
														<input
															id="surly_replace_urls_nowhere"
															name="surly_replace_urls[]"
															value="0"
															type="checkbox"
															<?php if (in_array(0, surly_get_option('surly_replace_urls', array(0), true))): ?>checked="checked"<?php endif; ?>/>
													</li>
													<li>
														<label for="surly_replace_urls_posts"><?php echo $lang_surly['posts']; ?></label>
														<input
															id="surly_replace_urls_posts"
															name="surly_replace_urls[]"
															value="1"
															type="checkbox"
															<?php if (in_array(1, surly_get_option('surly_replace_urls', array(0), true))): ?>checked="checked"<?php endif; ?>/>
													</li>
												</ul>
											</div>
										</div>
									</div>
									<div class="ps-cell">
										<div class="surly-field-error" data-field="surly-replace-urls">
											<div <?php if (in_array(0, surly_get_option('surly_replace_urls', array(0), true))): ?>class="ps-title-cell red" style="display:block"<?php else: ?>style="display:none;"<?php endif; ?>>
												<p><?php echo $lang_surly['links not protected']; ?></p>
											</div>
										</div>
										<div class="ps-title-cell">
											<p><? echo $lang_surly['sur.ly can work for all outbound links on your site']; ?></p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
				<div class="ps-type-buttons">
					<a id="surly-save-settings" href="#" class="ps-type-button blue"><?php echo $lang_surly['save changes']; ?></a>
				</div>
				<div class="ps-rows-settings">
					<div class="ps-row-box">
						<div class="ps-inner-box">
							<div class="ps-title-box">
								<p><?php echo $lang_surly['customize surly']; ?></p>
							</div>
							<div class="ps-show-info">
								<a id="surly-set-up-plugin-img" href="#"><div class="toolbar-img"></div></a>
							</div>
						</div>
						<div class="ps-type-buttons ps-mess">
							<a id="surly-set-up-plugin" href="#" class="ps-type-button blue"><?php echo $lang_surly['configure surly']; ?></a>
							<p class="ps-start"><?php echo $lang_surly['get the most out']; ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>