<?php

if (!defined('SURLY_INSTALL')) die();

if (!defined('FORUM_CACHE_FUNCTIONS_LOADED')) {
	require_once FORUM_ROOT . 'include/cache.php';
}

require_once $ext_info['path'] . '/include/functions.php';

if (!$forum_db->table_exists('shortener_cache')) {
	
	$schema = array(
		'FIELDS' => array(
			'long_url' => array(
				'datatype' => 'varchar(1000)'
			),
			'hash' => array(
				'datatype' => 'binary(16)',
				'allow_null' => false
			),
			'short_id' => array(
				'datatype' => 'varchar(10)'
			)
		),
		'PRIMARY KEY' => array('hash', '`long_url`(100)')
	);

	$forum_db->create_table('shortener_cache', $schema);
}

surly_set_option('surly_activation_hash', md5(time()));

generate_config_cache();

require FORUM_CACHE_DIR . 'cache_config.php';

$surly = surly_get_sdk();
$surly->trackHistory(SURLY_ACTION_TYPE_INSTALL);