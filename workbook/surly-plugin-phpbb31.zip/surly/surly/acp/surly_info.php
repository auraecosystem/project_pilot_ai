<?php
/**
*
* @package Sur.ly
* @copyright (c) 2014 Sur.ly <http://sur.ly>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace surly\surly\acp;

class surly_info
{
	public function module()
	{
		return array(
			'filename' => '\surly\surly\acp\surly_module',
			'title' => 'ACP_SURLY_MODULE',
			'modes' => array(
				'surly-settings-plugin' => array(
					'title' => 'ACP_SURLY_TAB_PLUGIN_SETTINGS',
					'auth' => 'ext_surly/surly && acl_a_surly',
					'cat' => array('ACP_SURLY_MODULE'),
				),
				'surly-settings-toolbar' => array(
					'title' => 'ACP_SURLY_TAB_TOOLBAR_SETTINGS',
					'auth' => 'ext_surly/surly && acl_a_surly',
					'cat' => array('ACP_SURLY_MODULE'),
					'display' => false,
				),
			),
		);
	}
}
