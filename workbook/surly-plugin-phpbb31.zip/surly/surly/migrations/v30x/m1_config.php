<?php
/**
*
* @package Sur.ly
* @copyright (c) 2014 Sur.ly <http://sur.ly>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace surly\surly\migrations\v30x;

/**
* Migration stage 1: Configs
*/
class m1_config extends \phpbb\db\migration\migration
{
	/**
	* Assign migration file dependencies for this migration
	*
	* @return array Array of migration files
	* @static
	* @access public
	*/
	static public function depends_on()
	{
		return array('\surly\surly\migrations\v10x\m2_initial_data');
	}

	/**
	* Add or update data in the database
	*
	* @return array Array of table data
	* @access public
	*/
	public function update_data()
	{
		return array(
			array('config.remove', array('surly_check_secondary_groups')),
			array('config.remove', array('surly_url_processing')),
			array('config.add', array('surly_activation_hash', md5(time()))),
			array('config.add', array('surly_replace_urls', '')),
			array('config.add', array('surly_initial', '')),
			array('config.add', array('surly_toolbar_id', '')),
			array('config.add', array('surly_toolbar_password', '')),
		);
	}
}
