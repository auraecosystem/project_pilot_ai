<?php
/**
*
* @package Sur.ly
* @copyright (c) 2014 Sur.ly <http://sur.ly>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	// ACP modules
	'ACP_CAT_SURLY' => 'Sur.ly',
	'ACP_SURLY_MODULE' => 'Sur.ly',
	'ACP_SURLY_TAB_PLUGIN_SETTINGS' => 'Sur.ly plugin settings',
	'ACP_SURLY_TAB_TOOLBAR_SETTINGS' => 'Toolbar settings',
));
