<?php
/**
*
* @package Sur.ly
* @copyright (c) 2014 Sur.ly <http://sur.ly>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace surly\surly;

class ext extends \phpbb\extension\base
{
	public function enable_step($old_state)
	{
		if (false === $old_state) {
			$surly = new \surly\surly\operators\surly_phpbb($this->container->get('dbal.conn'), $this->container->get('config'));
			$surly->trackHistory(\surly\surly\operators\surly_phpbb::SURLY_ACTION_TYPE_INSTALL);
		}

		return parent::enable_step($old_state);
	}

	public function disable_step($old_state)
	{
		if (false === $old_state) {
			$surly = new \surly\surly\operators\surly_phpbb($this->container->get('dbal.conn'), $this->container->get('config'));
			$surly->trackHistory(\surly\surly\operators\surly_phpbb::SURLY_ACTION_TYPE_DEACTIVATION);
		}

		return parent::disable_step($old_state);
	}

	public function purge_step($old_state)
	{
		if (false === $old_state) {
			$surly = new \surly\surly\operators\surly_phpbb($this->container->get('dbal.conn'), $this->container->get('config'));
			$surly->trackHistory(\surly\surly\operators\surly_phpbb::SURLY_ACTION_TYPE_UNINSTALL);
		}

		return parent::purge_step($old_state);
	}
}
