<?php
/**
*
* @package Sur.ly
* @copyright (c) 2014 Sur.ly <http://sur.ly>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace surly\surly\migrations\v30x;

/**
* Migration stage 3: Add module
*/
class m3_add_module extends \phpbb\db\migration\migration
{
	/**
	* Assign migration file dependencies for this migration
	*
	* @return array Array of migration files
	* @static
	* @access public
	*/
	static public function depends_on()
	{
		return array('\surly\surly\migrations\v30x\m2_remove_module');
	}

	/**
	* Add or update data in the database
	*
	* @return array Array of table data
	* @access public
	*/
	public function update_data()
	{
		return array(
			array('module.add', array('acp', false, 'ACP_CAT_SURLY')),
			array('module.add', array('acp', 'ACP_CAT_SURLY', 'ACP_SURLY_MODULE')),
			array('module.add', array('acp', 'ACP_SURLY_MODULE', array('module_basename' => '\surly\surly\acp\surly_module'))),
		);
	}
}
