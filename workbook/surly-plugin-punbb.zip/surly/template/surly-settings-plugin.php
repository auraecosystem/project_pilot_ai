<div class="main-content">
	<div class="wrapper-surly" data-token="<?php echo generate_form_token(forum_link($forum_url['surly'])); ?>">
		<div id="surly-message" class="updated notice notice-success is-dismissible" style="display:none"><p><?php echo $lang_surly['settings saved']; ?></p></div>
		<div class="ps-window">
			<div class="ps-central-content">
				<div class="ps-rows-settings">
					<form id="surly-save-settings-form">
						<input type="hidden" name="csrf_token" value="<?php echo generate_form_token(forum_link($forum_url['surly'])); ?>"/>
						<input type="hidden" name="action" value="surly_ajax_save_settings"/>
						<div id="surly-replace-urls" class="ps-row-box">
							<div class="ps-inner-box">
								<div class="ps-title-box">
									<p><?php echo $lang_surly['replace urls']; ?></p>
								</div>
								<div class="ps-table-box">
									<div class="ps-cell">
										<div class="w280">
											<div class="ps-list-in<?php if (in_array(0, surly_get_option('surly_replace_urls', array(0), true))): ?> field-error<?php endif; ?>">
												<ul>
													<li>
														<label for="surly_replace_urls_nowhere"><?php echo $lang_surly['nowhere']; ?></label>
														<input
															id="surly_replace_urls_nowhere"
															name="surly_replace_urls[]"
															value="0"
															type="checkbox"
															<?php if (in_array(0, surly_get_option('surly_replace_urls', array(0), true))): ?>checked="checked"<?php endif; ?>/>
													</li>
													<li>
														<label for="surly_replace_urls_posts"><?php echo $lang_surly['posts']; ?></label>
														<input
															id="surly_replace_urls_posts"
															name="surly_replace_urls[]"
															value="1"
															type="checkbox"
															<?php if (in_array(1, surly_get_option('surly_replace_urls', array(0), true))): ?>checked="checked"<?php endif; ?>/>
													</li>
												</ul>
											</div>
										</div>
									</div>
									<div class="ps-cell">
										<div class="surly-field-error" data-field="surly-replace-urls">
											<div <?php if (in_array(0, surly_get_option('surly_replace_urls', array(0), true))): ?>class="ps-title-cell red" style="display:block"<?php else: ?>style="display:none;"<?php endif; ?>>
												<p><?php echo $lang_surly['links not protected']; ?></p>
											</div>
										</div>
										<div class="ps-title-cell">
											<p><? echo $lang_surly['sur.ly can work for all outbound links on your site']; ?></p>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="ps-row-box">
							<div class="ps-inner-box">
								<div class="ps-title-box">
									<p><?php echo $lang_surly['shorten urls']; ?></p>
								</div>
								<div class="ps-cell">
									<div class="w280">
										<div class="ps-cell">
											<div class="ps-select-in">
												<select name="surly_shorten_urls">
													<option value="0"<?php if (!surly_get_option('surly_shorten_urls', false)): ?> selected="selected"<?php endif; ?>><?php echo $lang_surly['disable']; ?></option>
													<option value="1"<?php if (surly_get_option('surly_shorten_urls', false)): ?> selected="selected"<?php endif; ?>><?php echo $lang_surly['enable']; ?></option>
												</select>
											</div>
										</div>
									</div>
								</div>
								<div class="ps-cell">
									<div class="ps-title-cell">
										<p><?php echo sprintf($lang_surly['enable url shortening'], surly_get_option('surly_toolbar_id', SURLY_DEFAULT_TOOLBAR_ID)); ?></p>
									</div>
								</div>
							</div>
						</div>
						<div id="surly-subdomain" class="ps-row-box">
							<div class="ps-inner-box">
								<div class="ps-title-box">
									<p><?php echo $lang_surly['use your subdomain']; ?></p>
								</div>
								<div class="ps-table-box">
									<div class="ps-cell">
										<div class="w280">
											<div class="ps-type-in">
												<input name="surly_subdomain" value="<?php echo surly_get_option('surly_subdomain', ''); ?>" type="text" placeholder="<?php echo $lang_surly['url']; ?>"/>
											</div>
										</div>
									</div>
									<div class="ps-cell">
										<div class="surly-field-error" data-field="surly-subdomain"></div>
										<div class="ps-title-cell">
											<p><?php echo sprintf($lang_surly['set up a subdomain'], 'https://surdotly.com/setting_subdomain#dns'); ?></p>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="ps-row-box">
							<div class="ps-inner-box">
								<div class="ps-title-box">
									<p><?php echo $lang_surly['trusted groups']; ?></p>
								</div>
								<div class="ps-table-box">
									<div class="ps-cell">
										<div class="w280">
											<div class="ps-list-in trusted-groups">
												<ul>
													<?php foreach(surly_get_groups() as $key => $value): ?>
														<li>
															<label for="surly_trusted_groups-<?php echo $key; ?>">
																<?php echo $value; ?>
															</label>
															<input
																id="surly_trusted_groups-<?php echo $key; ?>"
																name="surly_trusted_groups[]"
																value="<?php echo $key; ?>"
																type="checkbox"
																<?php if (in_array($key, surly_get_option('surly_trusted_groups', array(), true))): ?>checked="checked"<?php endif; ?>/>
														</li>
													<?php endforeach; ?>
												</ul>
											</div>
										</div>
									</div>
									<div class="ps-cell">
										<div class="ps-title-cell">
											<p><?php echo $lang_surly['select the trusted user groups']; ?></p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</form>
					<form id="surly-trusted-domains">
						<div class="ps-row-box">
							<div class="ps-inner-box">
								<div class="ps-title-box">
									<p><?php echo $lang_surly['trusted domains']; ?></p>
								</div>
								<div class="ps-table-box">
									<div class="ps-cell">
										<div class="w430">
											<div class="ps-type-in">
												<input id="surly-trusted-domain" name="surly_trusted_domain" value="" placeholder="<?php echo $lang_surly['domain']; ?>"/>
												<div class="ps-type-buttons">
													<a id="surly-save-trusted-domain" href="#" class="ps-type-button blue"><?php echo $lang_surly['add domain']; ?></a>
												</div>
											</div>
										</div>
									</div>
									<div class="ps-cell">
										<div class="surly-field-error" data-field="surly-trusted-domain"></div>
										<div class="ps-title-cell">
											<p><?php echo $lang_surly['list your project’s link building partners']; ?></p>
										</div>
									</div>
								</div>
								<div class="ps-central-box">
									<div class="ps-table-line">
										<ul>
											<li class="first">
												<span class="ps-type-check">
													<input type="checkbox" value="1" id="surly_trusted_domains"/>
												</span>
												<label for="surly_trusted_domains"><?php echo $lang_surly['domain']; ?></label>
												<span class="num-item">
													<?php if (count(surly_get_option('surly_trusted_domains', array(), true)) == 1): ?>
														1 <?php echo $lang_surly['item']; ?>
													<?php else: ?>
														<?php echo count(surly_get_option('surly_trusted_domains', array(), true)); ?> <?php echo $lang_surly['items']; ?>
													<?php endif; ?>
												</span>
											</li>
											<?php foreach (surly_get_option('surly_trusted_domains', array(), true) as $key => $value): ?>
												<li class="inner">
													<span class="ps-type-check">
														<input
															id="surly_trusted_domains-<?php echo $key; ?>"
															name="surly_trusted_domains[]"
															value="<?php echo $value; ?>"
															type="checkbox"/>
													</span>
													<label for="surly_trusted_domains-<?php echo $key; ?>"><?php echo $value; ?></label>
												</li>
											<?php endforeach ;?>
											<?php if (surly_get_option('surly_trusted_domains', array(), true)): ?>
												<li class="empty" style="display:none;"><label><?php echo $lang_surly['no items found']; ?></label></li>
											<?php else: ?>
												<li class="empty"><label><?php echo $lang_surly['no items found']; ?></label></li>
											<?php endif; ?>
										</ul>
										<div class="ps-type-buttons">
											<a id="surly-delete-trusted-domains" href="#" class="ps-type-button ps-border lred pad30"><?php echo $lang_surly['delete']; ?></a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
				<div class="ps-type-buttons">
					<a id="surly-save-settings" href="#" class="ps-type-button blue"><?php echo $lang_surly['save changes']; ?></a>
				</div>
			</div>
		</div>
	</div>
</div>