<?php
/**
*
* @package Sur.ly
* @copyright (c) 2014 Sur.ly <http://sur.ly>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'ACP_SURLY' => 'Sur.ly',
	'ACP_SURLY_TAB_PLUGIN_SETTINGS' => 'Sur.ly plugin settings',
	'ACP_SURLY_TAB_TOOLBAR_SETTINGS' => 'Toolbar settings',
	'ACP_SURLY_ERROR_SUBDOMAIN_REQUIRE' => 'Invalid subdomain name: please check spelling and punctuation.',
	'ACP_SURLY_ERROR_SUBDOMAIN_INVALID' => 'Please use your website’s existing subdomain.',
	'ACP_SURLY_ERROR_SUBDOMAIN_EXIST' => 'Sorry, this subdomain is already in use.',
	'ACP_SURLY_ERROR_SUBDOMAIN_CNAME' => 'Incorrect CNAME record, please check your subdomain settings.',
	'ACP_SURLY_ERROR_DOMAIN_NAME' => 'Invalid domain name: please check spelling and punctuation.',
	'ACP_SURLY_ERROR_DOMAIN_EXIST' => 'This domain is already in the list.',
	'ACP_SURLY_ERROR_UNEXPECTED' => 'An unexpected error occured, and we are sorry about it.',
	'ACP_SURLY_MESSAGE_CONFIGURATION_SURLY' => 'Your website and visitors are not yet protected by Sur.ly. Be sure to enable it for your outbound links.',
	'ACP_SURLY_MESSAGE_SETTINGS_SAVED' => 'Settings saved.',
	'ACP_SURLY_TITLE_CONFIGURATION_TOOLBAR' => 'Configure your toolbar',
	'ACP_SURLY_TITLE_URL_PROCESSING' => 'URL processing',
	'ACP_SURLY_TITLE_REPLACE_URLS' => 'Replace URLs',
	'ACP_SURLY_TITLE_SHORTEN_URLS' => 'Shorten URLs',
	'ACP_SURLY_TITLE_DOMAINS' => 'Domains',
	'ACP_SURLY_TITLE_SUBDOMAIN' => 'Use your subdomain',
	'ACP_SURLY_TITLE_TRUSTED_DOMAINS' => 'Trusted domains',
	'ACP_SURLY_TITLE_TRUSTED_GROUPS' => 'Trusted groups',
	'ACP_SURLY_TITLE_REGISTRATION' => 'Registration',
	'ACP_SURLY_TITLE_CUSTOMIZE' => 'Customize Sur.ly for maximum effect',
	'ACP_SURLY_DESCRIPTION_SUBDOMAIN' => 'If you have a subdomain set up according to <a href="https://surdotly.com/setting_subdomain#dns">instructions</a>, just enter its name to allow viewing external pages via it.',
	'ACP_SURLY_DESCRIPTION_TRUSTED_DOMAINS' => 'List your project’s link building partners (or other trusted websites) here and keep all the outbound linking to their domains & subdomains untouched.',
	'ACP_SURLY_DESCRIPTION_TRUSTED_GROUPS' => 'Select the trusted user groups whose links should stay untouched.',
	'ACP_SURLY_DESCRIPTION_SHORTEN_URLS' => 'Enable URL shortening (optionally): all links replaced by Sur.ly will be shortened and formatted like http://sur.ly/o/bN/%s.',
	'ACP_SURLY_DESCRIPTION_REPLACE_URLS' => 'Sur.ly can work for links in Comments, Posts, or for all outbound links on your site.',
	'ACP_SURLY_BUTTON_NEXT' => 'Next',
	'ACP_SURLY_BUTTON_FINISH' => 'Finish',
	'ACP_SURLY_BUTTON_ADD_DOMAIN' => 'Add domain',
	'ACP_SURLY_BUTTON_DELETE' => 'Delete',
	'ACP_SURLY_BUTTON_SAVE_CHANGES' => 'Save changes',
	'ACP_SURLY_BUTTON_CONFIGURATION_SURLY' => 'Configure Sur.ly',
	'ACP_SURLY_PLACEHOLDER_URL' => 'URL',
	'ACP_SURLY_PLACEHOLDER_DOMAIN' => 'Domain',
	'ACP_SURLY_OPTION_ENABLE' => 'Enable',
	'ACP_SURLY_OPTION_DISABLE' => 'Disable',
	'ACP_SURLY_OPTION_NOWHERE' => 'Nowhere',
	'ACP_SURLY_OPTION_POSTS' => 'Posts',
	'ACP_SURLY_LABEL_DOMAIN' => 'Domain',
	'ACP_SURLY_LABEL_ITEM' => 'item',
	'ACP_SURLY_LABEL_ITEMS' => 'items',
	'ACP_SURLY_LABEL_NO_ITEMS_FOUND' => 'No items found',
	'ACP_SURLY_LABEL_TUNING' => 'and get the most out of outbound links with fine tuning.',
));
