<?php
/*
 * Copyright (c) 2012-2017 Sur.ly
 * This file is part of Sur.ly PunBB plugin.
 * 
 * Sur.ly PunBB plugin plugin is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Sur.ly PunBB plugin is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Sur.ly PunBB plugin.  If not, see <http://www.gnu.org/licenses/>.
 */

if (!defined('FORUM')) die();

$forum_url['surly'] = 'misc.php?section=surly';
$forum_url['surly_settings_toolbar'] = 'misc.php?section=surly&tab=settings-toolbar';

